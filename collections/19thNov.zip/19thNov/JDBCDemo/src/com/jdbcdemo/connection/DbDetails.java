package com.jdbcdemo.connection;

public interface DbDetails {

	String CONSTR = "jdbc:mysql://localhost:3306/cdac_tvm?useSSL=false";
	String DBDRIVER = "com.mysql.cj.jdbc.Driver";
	String USERNAME = "root";
	String PASSWORD = "root";
}
